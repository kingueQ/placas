/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

/**
 * Clase que permite poner los numerod de pagina
 * @author Abraham Quintana y Juan Gamez
 */
public class NumeroPagina extends PdfPageEventHelper {
 
    /**
     * Metodo que permite posicionarse al final de la pagina
     * @param writer Texto a escribir
     * @param document Documento en donde se escribira
     */
    @Override
    public void onEndPage(PdfWriter writer, Document document) {
        PdfContentByte cb = writer.getDirectContent();
        Font font = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
        Phrase phrase = new Phrase("Página " + writer.getPageNumber(), font);
        ColumnText.showTextAligned(cb, Element.ALIGN_CENTER, phrase,
                (document.right() - document.left()) / 2 + document.leftMargin(), 
                document.bottom() - 10, 0);
    }
 
}
