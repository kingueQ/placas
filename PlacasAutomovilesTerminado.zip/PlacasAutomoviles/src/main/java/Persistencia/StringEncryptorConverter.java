/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

/**
 *
 * @author juanc
 */
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
//import org.jasypt.intf.cli.JasyptPBEStringEncryptionCLI;

/**
 * Clase que guarda los metodos para encriptar y desencriptar los valores de un atributo
 * @author Abraham Quintana y Juan Gamez
 */
@Converter
public class StringEncryptorConverter implements AttributeConverter<String, String> {

    /**
     * Metodo que encripta un atributo
     * @param attribute Atributo a encriptar
     * @return el atributo encriptado
     */
    @Override
    public String convertToDatabaseColumn(String attribute) {
        return Jaspy.encrypt(attribute);
        
    }

    /**
     * Metodo que desencripta un atributo
     * @param dbData Valor encriptado
     * @return El atributo desencriptado
     */
    @Override
    public String convertToEntityAttribute(String dbData) {
        return Jaspy.decrypt(dbData);
    }

}
