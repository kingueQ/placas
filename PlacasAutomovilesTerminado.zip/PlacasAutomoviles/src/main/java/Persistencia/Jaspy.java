/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

/**
 * Clase que permite encriptar los nombres
 * @author Abraham Quintana y Juan Gamez
 */
public class Jaspy {
    private static final String PASSWORD = "mySecretPassword";
    private static final String ALGORITHM = "PBEWithMD5AndDES";

    private static final StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();

    static {
        encryptor.setPassword(PASSWORD);
        encryptor.setAlgorithm(ALGORITHM);
    }

    /**
     * Metodo que encripta un texto
     * @param text Texto a encriptar
     * @return el texto encriptado
     */
    public static String encrypt(String text) {
        return encryptor.encrypt(text);
    }

    /**
     * Metodo que desencripta un texto
     * @param text Texto a desencriptar
     * @return El texto desencriptado
     */
    public static String decrypt(String text) {
        return encryptor.decrypt(text);
    }

}
