/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Persistencia.ControladorPersistencia;
import Persistencia.NumeroPagina;
import Persistencia.Validaciones;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
import entidades.Licencia;
import entidades.Placa;
import java.awt.Desktop;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Clase que genera los reportes
 *
 * @author Abraham Quintana y Juan Gamez
 */
public class Reporte extends javax.swing.JFrame {

    private byte pag = 1;
    List<Placa> placas;
    List<Licencia> licencias;
    Validaciones validaciones = new Validaciones();
    private ControladorPersistencia cp = new ControladorPersistencia();

    /**
     * Creates new form Reporte
     */
    public Reporte() {
        initComponents();

        ImageIcon icon = new ImageIcon("logo.png");
        this.setIconImage(icon.getImage());

        this.limpiar();
        licencias = new ArrayList<>();
        placas = new ArrayList<>();

        this.buscarNombre();
        this.buscarFechaDesde();
        this.buscarFechaHasta();
    }

    /**
     * Metodo que llena la tabla
     *
     * @param pag Pagina de la tabla
     */
    private void llenarTabla(int pag) {
        int tam = licencias.size();
        int tamMax = licencias.size() + placas.size();
        if (tamMax == 0) {
            this.limpiar();
        } else {
            int fila = 0;
            for (int i = (pag - 1) * 5; i < (pag * 5); i++) {
                if (tam > i) {
                    this.tblTramites.setValueAt(licencias.get(i).getFecha_expedicion(), fila, 0);
                    this.tblTramites.setValueAt("Licencia", fila, 1);
                    if (licencias.get(i).getPersona().getApellidoM() == null) {
                        this.tblTramites.setValueAt(licencias.get(i).getPersona().getNombres() + " " + licencias.get(i).getPersona().getApellidoP(), fila, 2);
                    } else {
                        this.tblTramites.setValueAt(licencias.get(i).getPersona().getNombres() + " " + licencias.get(i).getPersona().getApellidoP() + " " + licencias.get(i).getPersona().getApellidoM(), fila, 2);
                    }
                    this.tblTramites.setValueAt(licencias.get(i).getCosto(), fila, 3);
                    fila++;
                } else {
                    if (tamMax > i) {
                        this.tblTramites.setValueAt(placas.get(i - tam).getFecha_emision(), fila, 0);
                        this.tblTramites.setValueAt("Placa", fila, 1);
                        if (placas.get(i - tam).getAutomovil().getPersona().getApellidoM() == null) {
                            this.tblTramites.setValueAt(placas.get(i - tam).getAutomovil().getPersona().getNombres() + " " + placas.get(i - tam).getAutomovil().getPersona().getApellidoP(), fila, 2);
                        } else {
                            this.tblTramites.setValueAt(placas.get(i - tam).getAutomovil().getPersona().getNombres() + " " + placas.get(i - tam).getAutomovil().getPersona().getApellidoP() + " " + placas.get(i - tam).getAutomovil().getPersona().getApellidoM(), fila, 2);
                        }
                        this.tblTramites.setValueAt(placas.get(i - tam).getCosto(), fila, 3);
                        fila++;
                    } else {
                        this.tblTramites.setValueAt("", fila, 0);
                        this.tblTramites.setValueAt("", fila, 1);
                        this.tblTramites.setValueAt("", fila, 2);
                        this.tblTramites.setValueAt("", fila, 3);
                        fila++;
                    }
                }
            }
        }
    }

   
    
    /**
     * Metodo que limpia la tabla
     */
    private void limpiar() {
        for (int i = 0; i < 5; i++) {
            this.tblTramites.setValueAt("", i, 0);
            this.tblTramites.setValueAt("", i, 1);
            this.tblTramites.setValueAt("", i, 2);
            this.tblTramites.setValueAt("", i, 3);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tblTramitesCompleta = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtDesde = new com.toedter.calendar.JDateChooser();
        jLabel7 = new javax.swing.JLabel();
        txtHasta = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        txtTipo = new javax.swing.JComboBox<>();
        txtFecha = new com.toedter.calendar.JDateChooser();
        txtTipoTramite = new javax.swing.JTextField();
        txtPersona = new javax.swing.JTextField();
        txtCosto = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        btnPDF = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTramites = new javax.swing.JTable();
        btnSig = new javax.swing.JButton();
        btnAnt = new javax.swing.JButton();
        lblPag = new javax.swing.JLabel();

        tblTramitesCompleta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Fecha", "Tipo", "Nombre", "Costo"
            }
        ));
        tblTramitesCompleta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTramitesCompletaMouseClicked(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 0), 7));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Reporte");

        jLabel2.setText("Fecha:");

        jLabel3.setText("Tipo de trámite:");

        jLabel4.setText("Nombre:");

        jLabel5.setText("Costo:");

        jLabel6.setText("Desde:");

        txtDesde.setBackground(new java.awt.Color(255, 255, 255));
        txtDesde.setForeground(new java.awt.Color(255, 255, 255));

        jLabel7.setText("Hasta:");

        txtHasta.setBackground(new java.awt.Color(255, 255, 255));
        txtHasta.setForeground(new java.awt.Color(255, 255, 255));

        jLabel8.setText("Tipo:");

        txtTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ambos", "Licencia", "Placa" }));
        txtTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTipoActionPerformed(evt);
            }
        });

        txtFecha.setBackground(new java.awt.Color(255, 255, 255));
        txtFecha.setForeground(new java.awt.Color(255, 255, 255));

        txtTipoTramite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTipoTramiteActionPerformed(evt);
            }
        });

        jLabel9.setText("Nombre:");

        btnPDF.setBackground(new java.awt.Color(255, 0, 0));
        btnPDF.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnPDF.setForeground(new java.awt.Color(255, 255, 255));
        btnPDF.setText("Generar PDF");
        btnPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDFActionPerformed(evt);
            }
        });

        btnRegresar.setBackground(new java.awt.Color(255, 0, 0));
        btnRegresar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegresar.setForeground(new java.awt.Color(255, 255, 255));
        btnRegresar.setText("Regresar");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        tblTramites.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Fecha", "Tipo", "Nombre", "Costo"
            }
        ));
        tblTramites.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTramitesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblTramites);

        btnSig.setBackground(new java.awt.Color(255, 0, 0));
        btnSig.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSig.setForeground(new java.awt.Color(255, 255, 255));
        btnSig.setText("Siguiente");
        btnSig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSigActionPerformed(evt);
            }
        });

        btnAnt.setBackground(new java.awt.Color(255, 0, 0));
        btnAnt.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAnt.setForeground(new java.awt.Color(255, 255, 255));
        btnAnt.setText("Anterior");
        btnAnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAntActionPerformed(evt);
            }
        });

        lblPag.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblPag.setText("1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(318, 318, 318)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnPDF)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRegresar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPersona)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtTipoTramite, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtCosto, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnAnt)
                                .addGap(131, 131, 131)
                                .addComponent(lblPag)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnSig))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtHasta, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 22, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(54, 54, 54)
                    .addComponent(txtDesde, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(527, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(jLabel6))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9)
                        .addComponent(txtTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8))
                    .addComponent(txtHasta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 102, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFecha, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTipoTramite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtPersona, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtCosto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAnt)
                    .addComponent(lblPag)
                    .addComponent(btnSig))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPDF)
                    .addComponent(btnRegresar))
                .addGap(14, 14, 14))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(40, 40, 40)
                    .addComponent(txtDesde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(345, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Metodo que se activa al presionar regresar
     *
     * @param evt Presionar el boton
     */
    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        // TODO add your handling code here:
        Login inicial = new Login();
        this.setVisible(false);
        inicial.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed

    /**
     * Metodo que se activa al presionar ant
     *
     * @param evt Presionar el boton
     */
    private void btnAntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAntActionPerformed
        // TODO add your handling code here:
        if (this.lblPag.getText().equals("1")) {

        } else {
            Integer pag = Integer.parseInt(this.lblPag.getText());
            pag--;
            lblPag.setText(pag.toString());
            this.llenarTabla(pag);
        }
    }//GEN-LAST:event_btnAntActionPerformed

    /**
     * Metodo que se activa al presionar sig
     *
     * @param evt Presionar el boton
     */
    private void btnSigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSigActionPerformed
        // TODO add your handling code here:
        Integer max = licencias.size() + placas.size();
        if (max == 0) {
            return;
        }
        if (max % 5 != 0) {
            max = max / 5 + 1;
        } else {
            max = max / 5;
        }
        if (this.lblPag.getText().equals(max.toString())) {

        } else {
            Integer pag = Integer.parseInt(this.lblPag.getText());
            pag++;
            lblPag.setText(pag.toString());
            this.llenarTabla(pag);
        }
    }//GEN-LAST:event_btnSigActionPerformed

    /**
     * Metodo que se activa al presionar un registro de la tabla
     *
     * @param evt Hacer click
     */
    private void tblTramitesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTramitesMouseClicked
        // TODO add your handling code here:
        int fila = this.tblTramites.getSelectedRow();
        if (this.tblTramites.getValueAt(fila, 0).toString().equals("")) {
            this.txtFecha.setDate(null);
        } else {
            this.txtFecha.setDate(new Date(this.tblTramites.getValueAt(fila, 0).toString()));
        }
        this.txtTipoTramite.setText(this.tblTramites.getValueAt(fila, 1).toString());
        this.txtPersona.setText(this.tblTramites.getValueAt(fila, 2).toString());
        this.txtCosto.setText(this.tblTramites.getValueAt(fila, 3).toString());
    }//GEN-LAST:event_tblTramitesMouseClicked

    /**
     * Metodo que permite hacer una busqueda dinamica mediante el tipo de tramite
     * @param evt Seleccionar una opcion en el combo box tipo
     */
    private void txtTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTipoActionPerformed
        int tipo = this.txtTipo.getSelectedIndex();
        if (tipo == 0) {
            licencias = cp.buscarTodasLicencia();
            placas = cp.buscarTodasPlacas();
        } else if (tipo == 1) {
            licencias = cp.buscarTodasLicencia();
            placas = new ArrayList<>();
        } else {
            placas = cp.buscarTodasPlacas();
            licencias = new ArrayList<>();
        }
        this.lblPag.setText("1");
        pag = 1;
        this.llenarTabla(pag);
    }//GEN-LAST:event_txtTipoActionPerformed

    private void txtTipoTramiteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTipoTramiteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTipoTramiteActionPerformed

    /**
     * Metodo que convierte la tabla a una String
     * @param table Tabla a convertir
     * @return El String resultante
     */
    public String convertirTablaAString(JTable table) {
        StringBuilder sb = new StringBuilder();

        for (int row = 0; row < table.getRowCount(); row++) {
            for (int col = 0; col < table.getColumnCount(); col++) {
                Object cellValue = table.getValueAt(row, col);
                sb.append(cellValue);

                if (col < table.getColumnCount() - 1) {
                    sb.append("      ");
                }
            }

            sb.append("\n");
        }

        return sb.toString();
    }

    /**
     * Metodo que convierte una lista a una String
     * @param Lista Lista a convertir
     * @return La cadena resultante
     */
    public String convertirListaString(List<?> Lista) {
        StringBuilder sb = new StringBuilder();
        for (Object p : Lista) {
            sb.append(p.toString()).append("\n");
        }
        String resultado = sb.toString();
        return resultado;
    }

    /**
     * Metodo que abre el PDF
     *
     * @param ruta Ruta del PDF
     * @throws IOException Excepcion que se lanza en caso de un error
     */
    public static void abrirPDF(String ruta) throws IOException {
        File file = new File(ruta);
        Desktop.getDesktop().open(file);
    }

    /**
     * Metodo que permite generar un documento PDF
     * @param evt Presionar el boton generar reporte
     */
    private void btnPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDFActionPerformed
        try {
            // Se crea el documento
            Document documento = new Document(PageSize.A4, 36, 36, 36, 36);
            PdfWriter writer = PdfWriter.getInstance(documento, new FileOutputStream("reporte.pdf"));
            writer.setPageEvent(new NumeroPagina());

            // Se abre el documento
            documento.open();

            // Se agrega contenido al PDF
            
            
            String infoTabla = convertirTablaAString(tblTramites);
            

            Font tituloFont = new Font(BaseFont.createFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 18, Font.NORMAL, BaseColor.BLACK);

            Paragraph tituloPara = new Paragraph("Reportes", tituloFont);
            tituloPara.setAlignment(Element.ALIGN_CENTER);

            Font subtituloFont = new Font(BaseFont.createFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 14, Font.NORMAL, BaseColor.BLACK);

    

            Font contenidoFont = new Font(BaseFont.createFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 12, Font.NORMAL, BaseColor.BLACK);
            Paragraph headTblLic = new Paragraph("|                      Fecha                     |       Tipo      |                   Nombre                   |      Costo     |", contenidoFont);         
            Paragraph contenidoTabla = new Paragraph(infoTabla, contenidoFont);

            LocalDateTime fechaHoraActual = LocalDateTime.now();

            // Crear un formateador de fecha y hora
            DateTimeFormatter formateador = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

            // Convertir la fecha y hora en un String con el formato deseado
            String fechaHoraActualString = fechaHoraActual.format(formateador);
            Paragraph contenidoFecha = new Paragraph("Fecha del reporte: " + fechaHoraActualString, contenidoFont);

            contenidoFecha.setAlignment(Element.ALIGN_LEFT);
            // Agregar párrafos al documento

            documento.add(contenidoFecha);
            documento.add(tituloPara);
            documento.add(headTblLic);
            documento.add(contenidoTabla);
            

            documento.close();

            JOptionPane.showMessageDialog(this, "PDF Generado Correctamente");

            try {
                String path = System.getProperty("user.dir") + "/reporte.pdf";
                abrirPDF(path);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al abrir el archivo");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnPDFActionPerformed

    private void tblTramitesCompletaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTramitesCompletaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblTramitesCompletaMouseClicked

    /**
     * Metodo que permite realizar busquedas dinamicas mediante el nombre
     */
    public void buscarNombre() {
        txtNombre.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                String nombre = txtNombre.getText();
                placas = cp.buscarPlacasNombre(nombre);
                licencias = cp.buscarLicenciasNombre(nombre);
                lblPag.setText("1");
                pag = 1;
                llenarTabla(pag);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                String nombre = txtNombre.getText();
                placas = cp.buscarPlacasNombre(nombre);
                licencias = cp.buscarLicenciasNombre(nombre);
                lblPag.setText("1");
                pag = 1;
                llenarTabla(pag);
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // TODO add your handling code here:
                String nombre = txtNombre.getText();
                placas = cp.buscarPlacasNombre(nombre);
                licencias = cp.buscarLicenciasNombre(nombre);
                lblPag.setText("1");
                pag = 1;
                llenarTabla(pag);
            }
        });
        {

        }

    }

    /**
     * Metodo que permite realizar busquedas dinamicas mediante el fin del intervalo
     */
    public void buscarFechaDesde() {
        txtDesde.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                Date inicio = txtDesde.getDate();
                Date fin = txtHasta.getDate();
                licencias = cp.consultarIntervaloLicencia(inicio, fin);
                placas = cp.consultarIntervaloPlacas(inicio, fin);
                lblPag.setText("1");
                pag = 1;
                llenarTabla(pag);
            }
        });
        {

        }

    }

    /**
     * Metodo que permite realizar consultas dinamicas mediante el inicio del periodo
     */
    public void buscarFechaHasta() {
        txtHasta.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                Date inicio = txtDesde.getDate();
                Date fin = txtHasta.getDate();
                licencias = cp.consultarIntervaloLicencia(inicio, fin);
                placas = cp.consultarIntervaloPlacas(inicio, fin);
                lblPag.setText("1");
                pag = 1;
                llenarTabla(pag);
            }
        });
        {

        }

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnt;
    private javax.swing.JButton btnPDF;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnSig;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblPag;
    private javax.swing.JTable tblTramites;
    private javax.swing.JTable tblTramitesCompleta;
    private javax.swing.JTextField txtCosto;
    private com.toedter.calendar.JDateChooser txtDesde;
    private com.toedter.calendar.JDateChooser txtFecha;
    private com.toedter.calendar.JDateChooser txtHasta;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPersona;
    private javax.swing.JComboBox<String> txtTipo;
    private javax.swing.JTextField txtTipoTramite;
    // End of variables declaration//GEN-END:variables
}
