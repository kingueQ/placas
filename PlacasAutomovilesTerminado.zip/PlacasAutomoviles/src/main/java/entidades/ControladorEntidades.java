/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import Persistencia.ControladorPersistencia;

/**
 * Clase que guarda los metodos de las entidas
 * @author Abraham Quintana y Juan Gamez
 */
public class ControladorEntidades {

    ControladorPersistencia cp = new ControladorPersistencia();

    //METODOS PARA PERSONA 
    /**
     * Metodo que agrega una persona
     * @param persona Persona a agregar
     */
    public void agregarPersona(Persona persona) {
        cp.agregarPersona(persona);
    }

    /**
     * Metodo que busca una persona
     * @param RFC RFC de la persona
     * @return La persona encontrada
     */
    public Persona buscarPersona(String RFC) {
        if (cp.buscarPersona(RFC) != null) {
            return cp.buscarPersona(RFC);
        } else {
            return null;
        }
    }

    //METODOS LICENCIA
    /**
     * Metodo que agrega una licencia
     * @param licencia Licencia a agregar
     */
    public void agregarLicencia(Licencia licencia) {
        cp.agregarLicencia(licencia);
    }

    /**
     * Metodo que obtiene los años de la licencia de una persona
     * @param persona Persona a quien pertenece la licencia
     * @return Los años de la licencia
     */
    public Long añosLicencia(Persona persona){
        return cp.añosLicencia(persona);
    }
    
    /**
     * Metodo que busca la licencia activa de una persona
     * @param persona Persona a la que pertenece la licencia
     * @return La licencia activa
     */
    public Licencia licenciaActiva(Persona persona) {
        return cp.licenciaActiva(persona);
    }

    /**
     * Metodo que desactiva una licencia
     * @param licencia Licencia a desactivar
     */
    public void desactivarLicencia(Licencia licencia){
        cp.desactivarLicencia(licencia);
    }
    
}
