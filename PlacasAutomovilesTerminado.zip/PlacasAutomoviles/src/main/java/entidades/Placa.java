/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Clase Placa
 * @author Abraham Quintana y Juan Gamez
 */
@Entity
@DiscriminatorValue("Placa")
public class Placa extends Tramite implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Basic
    private String numero;
    private boolean activa;
    private double costo;

    @Temporal(TemporalType.DATE)
    private Date fecha_emision;
    @Temporal(TemporalType.DATE)
    private Date fecha_recepcion;

    @ManyToOne()
    @JoinColumn(name = "automovil_id")
    private Automovil automovil;

    public Placa() {
    }

    public Placa(String numero, boolean activa, double costo, Date fecha_emision, Date fecha_recepcion, Automovil automovil) {
        this.numero = numero;
        this.activa = activa;
        this.costo = costo;
        this.fecha_emision = fecha_emision;
        this.fecha_recepcion = fecha_recepcion;
        this.automovil = automovil;
    }

    public Placa(Integer id, String numero, boolean activa, double costo, Date fecha_emision, Date fecha_recepcion, Automovil automovil) {
        this.id = id;
        this.numero = numero;
        this.activa = activa;
        this.costo = costo;
        this.fecha_emision = fecha_emision;
        this.fecha_recepcion = fecha_recepcion;
        this.automovil = automovil;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public Date getFecha_emision() {
        return fecha_emision;
    }

    public void setFecha_emision(Date fecha_emision) {
        this.fecha_emision = fecha_emision;
    }

    public Date getFecha_recepcion() {
        return fecha_recepcion;
    }

    public void setFecha_recepcion(Date fecha_recepcion) {
        this.fecha_recepcion = fecha_recepcion;
    }

    public Automovil getAutomovil() {
        return automovil;
    }

    public void setAutomovil(Automovil automovil) {
        this.automovil = automovil;
    }

    @Override
    public String toString() {
        String espacio = "    ";
        String estado;
        String fechaR;
        if (activa ==  false) {
            estado = "Activa";
        } else {
            estado = "Desactiva";
        }
         if (fecha_recepcion == null) {
                        fechaR = "No a sido recogida                  ";
                    } else {
                      fechaR = fecha_recepcion.toString();
                    }
        return numero + espacio + fecha_emision + espacio + fechaR + espacio + estado + espacio + costo;
    }

}
