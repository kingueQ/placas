/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import java.io.Serializable;
import javax.persistence.Query;
import entidades.Placa;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author kingu
 */
public class PlacaJPA implements Serializable {

    private EntityManagerFactory emf = null;

    public PlacaJPA(){
        emf=Persistence.createEntityManagerFactory("ConexionPU");
    }
    
    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public Placa agregarPlaca(Placa placa) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(placa);
            em.getTransaction().commit();
            placa=this.buscarPlaca(placa.getNumero());
            return placa;
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
                return null;
            }
        } finally {
            if (em != null) {
                em.close();
                return placa;
            }
        }
       return placa;
    }
    
    public Placa buscarPlaca(String numero) {
        EntityManager em = null;
        Placa placa = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Placa p where p.numero = :numero");
            query.setParameter("numero", numero);
            placa = (Placa) query.getSingleResult();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return placa;
    }
    
    public List<Placa> buscarPlacas(String serie) {
        EntityManager em = null;
        List<Placa> placas = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Placa p where p.Automovil.Serie = :Serie");
            query.setParameter("Serie", serie);
            placas = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return placas;
    }
    
    public void cancelarPlaca(Placa placa) {
        EntityManager em = null;
        placa.setActiva(false);
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(placa);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
}
