/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import entidades.Automovil;
import entidades.Licencia;
import entidades.Persona;
import entidades.Placa;
import java.util.List;

/**
 *
 * @author juanc
 */
public class ControladorPersistencia {
    PersonaJPA pJPA = new PersonaJPA();
    LicenciaJPA lJPA = new LicenciaJPA();
    AutomovilJPA aJPA=new AutomovilJPA();
    PlacaJPA plJPA=new PlacaJPA();
    //METODOS PERSONAS
    
    public void agregarPersona(Persona persona){
        pJPA.agregarPersona(persona);
    }
    
    public Persona buscarPesona(String RFC){
      if(pJPA.buscarPersona(RFC) != null){
          return pJPA.buscarPersona(RFC);
      }else{
          return null;
      }
       
    }
    
    //METODOS LICENCIA
    
    public void agregarLicencia(Licencia licencia){
        lJPA.agregarLicencia(licencia);
    }
    
    public Long añosLicencia(Persona persona){
       return lJPA.añosLicencia(persona);
    }
    
    public Licencia licenciaActiva(Persona persona){
        return lJPA.LicenciaActiva(persona);
    }
    
    public void desactivarLicencia(Licencia licencia){
         lJPA.desactivarLicencia(licencia);
    }
    
    //Metodos autos
    
    public Automovil agregarAuto(Automovil auto){
        return aJPA.agregarAutomovil(auto);
    }
    
    public Automovil buscarAuto(String serie){
        return aJPA.buscarAutomovil(serie);
    }
    
    public List<Automovil> buscarAutos(String RFC){
        return aJPA.buscarAutomoviles(RFC);
    }
    
    //Metodos placas
    
    public Placa agregarPlaca(Placa placa){
        return plJPA.agregarPlaca(placa);
    }
    
    public Placa buscarPlaca(String numero){
        return plJPA.buscarPlaca(numero);
    }
    
    public List<Placa> buscarPlacas(String serie){
        return plJPA.buscarPlacas(serie);
    }
    
    public void cancelarPlaca(Placa placa){
        plJPA.cancelarPlaca(placa);
    }
    
}
