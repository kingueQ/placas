/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import entidades.Automovil;
import java.io.Serializable;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author kingu
 */
public class AutomovilJPA implements Serializable {

    private EntityManagerFactory emf = null;

    public AutomovilJPA(){
        emf=Persistence.createEntityManagerFactory("ConexionPU");
    }
    
    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public Automovil agregarAutomovil(Automovil auto) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(auto);
            em.getTransaction().commit();
            auto=this.buscarAutomovil(auto.getSerie());
            return auto;
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
                return null;
            }
        } finally {
            if (em != null) {
                em.close();
                return auto;
            }
        }
        return auto;
    }
    
    public Automovil buscarAutomovil(String serie) {
        EntityManager em = null;
        Automovil auto = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT a FROM Automovil a where a.serie = :serie");
            query.setParameter("serie", serie);
            auto = (Automovil) query.getSingleResult();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return auto;
    }
    
    public List<Automovil> buscarAutomoviles(String rfc) {
        EntityManager em = null;
        List<Automovil> autos = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT a FROM Automovil a where a.persona.RFC = :RFC");
            query.setParameter("RFC", rfc);
            autos = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return autos;
    }
    
    
}
