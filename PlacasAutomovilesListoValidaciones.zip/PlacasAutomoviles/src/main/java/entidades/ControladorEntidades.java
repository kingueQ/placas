/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import Persistencia.ControladorPersistencia;

/**
 *
 * @author juanc
 */
public class ControladorEntidades {

    ControladorPersistencia cp = new ControladorPersistencia();

    //METODOS PARA PERSONA 
    public void agregarPersona(Persona persona) {
        cp.agregarPersona(persona);
    }

    public Persona buscarPesona(String RFC) {
        if (cp.buscarPesona(RFC) != null) {
            return cp.buscarPesona(RFC);
        } else {
            return null;
        }
    }

    //METODOS LICENCIA
    public void agregarLicencia(Licencia licencia) {
        cp.agregarLicencia(licencia);
    }

    public Long añosLicencia(Persona persona){
        return cp.añosLicencia(persona);
    }
    
    public Licencia licenciaActiva(Persona persona) {
        return cp.licenciaActiva(persona);
    }

    public void desactivarLicencia(Licencia licencia){
        cp.desactivarLicencia(licencia);
    }
    
}
