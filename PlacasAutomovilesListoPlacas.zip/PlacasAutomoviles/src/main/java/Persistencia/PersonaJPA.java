/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import entidades.Persona;
import java.io.Serializable;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author juanc
 */
public class PersonaJPA implements Serializable{
    
   private EntityManagerFactory em = null;

    public PersonaJPA() {
        em = Persistence.createEntityManagerFactory("ConexionPU");
    }
    
    public EntityManager getEntityManager() {
        return em.createEntityManager();
    }

    public Persona agregarPersona(Persona persona) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(persona);
            em.getTransaction().commit();
            return persona;
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
                
            }
        } finally {
            if (em != null) {
                em.close();
                return null;
            }
        }
       return null;
    }
    
    public Persona buscarPersona(String RFC) {
        EntityManager em = null;
        Persona persona = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Persona p where p.RFC = :RFC");
            query.setParameter("RFC", RFC);
            persona = (Persona) query.getSingleResult();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return persona;
    }
    
    
}
