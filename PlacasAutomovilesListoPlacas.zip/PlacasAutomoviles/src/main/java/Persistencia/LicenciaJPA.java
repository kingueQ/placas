/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import entidades.Licencia;
import entidades.Persona;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author juanc
 */
public class LicenciaJPA implements Serializable {

    private EntityManagerFactory em = null;

    public LicenciaJPA() {
        em = Persistence.createEntityManagerFactory("ConexionPU");
    }

    public EntityManager getEntityManager() {
        return em.createEntityManager();
    }

    public Licencia agregarLicencia(Licencia licencia) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(licencia);
            em.getTransaction().commit();
            return licencia;
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());

            }
        } finally {
            if (em != null) {
                em.close();
                return null;
            }
        }
        return null;
    }

    public Long añosLicencia(Persona persona) {
        int id = persona.getId();
        EntityManager em = null;
        em = getEntityManager();
        em.getTransaction().begin();
        CriteriaBuilder cb = em.getCriteriaBuilder();

        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<Licencia> root = cq.from(Licencia.class);

        cq.select(cb.function("TIMESTAMPDIFF", Long.class,
                cb.literal("YEAR"),
                root.get("fecha_expedicion"),
                cb.currentTimestamp()))
                .where(cb.and(
                        cb.equal(root.get("persona").get("id"), id),
                        cb.equal(root.get("activa"), false)
                ));

        TypedQuery<Long> query = em.createQuery(cq);
        Long años = query.getSingleResult();
        em.getTransaction().commit();
        return años;
    }

    public Licencia LicenciaActiva(Persona persona) {
        int id = persona.getId();
        EntityManager em = null;
        em = getEntityManager();
        em.getTransaction().begin();
        Query query = em.createQuery("SELECT l FROM Licencia l WHERE l.persona.id = :idPersona AND l.activa = false");
        query.setParameter("idPersona", id);
        List<Licencia> licencias = query.getResultList();
        if (licencias.isEmpty()) {
             return null;
        } else {
           Licencia licencia = licencias.get(0);
           return licencia;
        }      
    }
    
    public void desactivarLicencia(Licencia licencia){
      EntityManager em = null;
      licencia.setActiva(true);
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(licencia);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
        
    }

}
