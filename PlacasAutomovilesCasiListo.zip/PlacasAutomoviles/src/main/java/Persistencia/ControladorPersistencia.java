/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import entidades.Automovil;
import entidades.Licencia;
import entidades.Persona;
import entidades.Placa;
import java.util.Date;
import java.util.List;

/**
 * Clase que guarda todos los metodos de persistencia
 * @author Abraham Quintana y Juan Gamez
 */
public class ControladorPersistencia {
    PersonaJPA pJPA = new PersonaJPA();
    LicenciaJPA lJPA = new LicenciaJPA();
    AutomovilJPA aJPA=new AutomovilJPA();
    PlacaJPA plJPA=new PlacaJPA();
    //METODOS PERSONAS
    
    /**
     * Metodo que agrega una persona
     * @param persona 
     */
    public void agregarPersona(Persona persona){
        pJPA.agregarPersona(persona);
    }
    
    /**
     * Metodo que busca una persona
     * @param RFC RFC de la persona
     * @return La persona encontrada
     */
    public Persona buscarPersona(String RFC){
      if(pJPA.buscarPersona(RFC) != null){
          return pJPA.buscarPersona(RFC);
      }else{
          return null;
      }
       
    }
    
    //METODOS LICENCIA
    /**
     * Metodo que agrega una licencia
     * @param licencia Licencia a agregar
     */
    public void agregarLicencia(Licencia licencia){
        lJPA.agregarLicencia(licencia);
    }
    
    /**
     * Metodo que obtiene los años de la licencia
     * @param persona Persona a la que pertenece la licencia
     * @return Los años de la licencia
     */
    public Long añosLicencia(Persona persona){
       return lJPA.añosLicencia(persona);
    }
    
    /**
     * Metodo que busca una licencia activa
     * @param persona Persona a la que pertenece la licencia
     * @return La licencia activa
     */
    public Licencia licenciaActiva(Persona persona){
        return lJPA.LicenciaActiva(persona);
    }
    
    /**
     * Metodo que desactiva una licencia
     * @param licencia Licencia a desactivar
     */
    public void desactivarLicencia(Licencia licencia){
         lJPA.desactivarLicencia(licencia);
    }
    
    //Metodos autos
    /**
     * Metodo que agrega un automovil
     * @param auto Automovil a agregar
     * @return EL auto agregado
     */
    public Automovil agregarAuto(Automovil auto){
        return aJPA.agregarAutomovil(auto);
    }
    
    /**
     * Metodo que busca un auto
     * @param serie Serie del auto
     * @return El auto encontrado
     */
    public Automovil buscarAuto(String serie){
        return aJPA.buscarAutomovil(serie);
    }
    
    /**
     * Metodo que busca los autos de una persona 
     * @param RFC RFC de la persona
     * @return La lista de autos
     */
    public List<Automovil> buscarAutos(String RFC){
        return aJPA.buscarAutomoviles(RFC);
    }
    
    //Metodos placas
    
    /**
     * Metodo que agrega una placa
     * @param placa Placa a agregar
     * @return Placa agregada
     */
    public Placa agregarPlaca(Placa placa){
        return plJPA.agregarPlaca(placa);
    }
    
    /**
     * Metodo que busca una placa
     * @param numero Numero de la placa
     * @return La placa encontrada
     */
    public Placa buscarPlaca(String numero){
        return plJPA.buscarPlaca(numero);
    }
    
    /**
     * Metodo que busca las placas de un auto
     * @param serie Serie del auto
     * @return La lista de placas
     */
    public List<Placa> buscarPlacas(String serie){
        return plJPA.buscarPlacas(serie);
    }
    
    /**
     * Metodo que cancela una placa
     * @param placa Placa a cancelar
     * @return Si se elimino la placa
     */
    public boolean cancelarPlaca(Placa placa){
        return plJPA.cancelarPlaca(placa);
    }
    
    /**
     * Metodo que busca la placa activa de un auto
     * @param serie Serie del auto
     * @return La placa activa
     */
    public Placa buscarPlacaActiva(String serie){
        return plJPA.buscarPlacaActiva(serie);
    }
    
    /**
     * Metodo que busca las placas de una persona
     * @param RFC RFC de la persona
     * @return Lista de las placas
     */
    public List<Placa> buscarPlacasPersona(String RFC){
        return plJPA.buscarPlacasPersona(RFC);
    }
    
    /**
     * Metodo que busca el automovil con cierta placa
     * @param numero Numero de la placa
     * @return El automovil encontrado
     */
    public Automovil buscarAutomovilPlaca(String numero){
        return aJPA.buscarAutomovilPlaca(numero);
    }
    
    /**
     * Metodo que busca las placas activas de una persona
     * @param RFC RFC de la persona
     * @return La lista de placas
     */
    public List<Placa> buscarPlacasActivasPersona(String RFC){
        return plJPA.buscarPlacasActivasPersona(RFC);
    }
    
    /**
     * Metodo que busca las placas de las personas con cierto nombre
     * @param nombre Nombre de la persona
     * @return La lista de placas
     */
    public List<Placa> buscarPlacasNombre(String nombre){
        return plJPA.buscarPlacasNombre(nombre);
    }
    
    /**
     * Metodo que busca las placas pertenecientes a una persona 
     * @param fecha Fecha de nacimiento de la persona
     * @return La lista de placas
     */
    public List<Placa> buscarPlacasFecha(Date fecha){
        return plJPA.buscarPlacasFecha(fecha);
    }
    
    /**
     * Metodo que obtiene las licencias de una persona
     * @param RFC RFC de las persona
     * @return La lista de licencias
     */
    public List<Licencia> buscarLicenciasPersona(String RFC){
        return lJPA.buscarLicenciasPersona(RFC);
    }
    
    /**
     * Metodo que busca las licencias pertenecientes a la fecha de nacimiento de una persona
     * @param fecha Fecha de nacimiento de la persona
     * @return La lista de licencias
     */
    public List<Licencia> buscarLicenciasFecha(Date fecha){
        return lJPA.buscarLicenciasFecha(fecha);
    }
    
    /**
     * Metodo que busca las licencias que pertenecen a un nonbre
     * @param nombre nombre de la persona
     * @return la lista de licencias
     */
    public List<Licencia> buscarLicenciasNombre(String nombre){
        return lJPA.buscarLicenciasNombre(nombre);
    }
    
    /**
     * Metodo que obtiene todas las licencias
     * @return Todas las licencias
     */
    public List<Licencia> buscarTodasLicencia(){
        return lJPA.buscarTodas();
    }
    
    /**
     * Metodo que obtiene las licencias dentro de un intervalo
     * @param inicio Inicio del intervalo
     * @param fin Fin del intervalo
     * @return La lista de licencias
     */
    public List<Licencia> consultarIntervaloLicencia(Date inicio, Date fin){
        return lJPA.consultarIntervalo(inicio, fin);
    }
    
    /**
     * Metodo que obtiene todas las placas
     * @return Todas las placas
     */
    public List<Placa> buscarTodasPlacas(){
        return plJPA.buscarTodas();
    }
    
    /**
     * Metodo que obtiene las placas dentro de un intervalo
     * @param inicio Inicio del intervalo
     * @param fin Fin del intervalo
     * @return La lista de placas
     */
    public List<Placa> consultarIntervaloPlacas(Date inicio, Date fin){
        return plJPA.consultarIntervalo(inicio, fin);
    }
    
    /**
     * Metodo que busca todas las personas que compartan nombre
     * @param nombre Nombre de las personas
     * @return La lista de personas
     */
    public List<Persona> buscarPersonasNombre(String nombre){
        return pJPA.buscarPersonasNombre(nombre);
    }
}
