/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Clase que contiene las validaciones del proyecto
 * @author Abraham Quintana y Juan Gamez
 */
public class Validaciones {
    /**
     * Metodo que valida el apellido paterno
     * @param s La cadena a verificar
     * @return El resultado de la validacion
     */
    public boolean validaApellidoP(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)){3,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida el apellido materno
     * @param s La cadena a verificar
     * @return El resultado de la validacion
     */
    public boolean validaApellidoM(String s){
        CharSequence cadena=s.trim();
        if(cadena.equals("")){
            return true;
        }
        String reCadena="^(([a-zA-Z]+)){3,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida los nombres de la persona
     * @param s Cadena a validar
     * @return El resultado de la validacion
     */
    public boolean validaNombres(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)(\\s[a-zA-Z])*){4,50}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida un numero de telefono
     * @param s Cadena a verificar
     * @return el resultado de la validacion
     */
    public boolean validaTelefono1(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([0-9]+)){10,12}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida un numero de telefono
     * @param s Cadena a verificar
     * @return el resultado de la validacion
     */
    public boolean validaTelefono2(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([0-9]+)&&-&&([0-9]+)&&-&&([0-9]+)){10,15}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida un RFC sin homoclave
     * @param s Cadena a evaluar
     * @return El resultado de la validacion
     */
    public boolean validaRFCSinHomoclave(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([A-Z]){4}([0-9]){6})";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida un RFC con homoclave
     * @param s Cadena a evaluar
     * @return El resultado de la validacion
     */
    public boolean validaRFCConHomoclave(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([A-Z]){4}([0-9]){6}([A-Z0-9]){3})";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida un numero de telefono
     * @param s Cadena a verificar
     * @return el resultado de la validacion
     */
    public boolean validaTelefono(String s){
        if(validaTelefono1(s)){
           return true; 
        }else{
            return validaTelefono2(s);
        }
    }
    
    /**
     * Metodo que valida un RFC
     * @param s Cadena a evaluar
     * @return El resultado de la validacion
     */
    public boolean validaRFC(String s){
        if(validaRFCSinHomoclave(s)){
            return true;
        }else{
            return validaRFCConHomoclave(s);
        }
    }
    
    /**
     * Metodo que valida una fecha de nacimiento
     * @param f Fecha a verificar
     * @return Si la persona es mayor de edad
     */
    public boolean validaNacimiento(Date f){
        Date d=new Date();
        if(d.getYear()-f.getYear()>18){
            return true;
        }
        if(d.getYear()-f.getYear()<18){
            return false;
        }else{
            if(d.getMonth()>f.getMonth()){
                return true;
            }
            if(d.getMonth()<f.getMonth()){
                return false;
            }else{
                if(d.getDay()>=f.getDay()){
                    return true;
                }else{
                    return false;
                }
            }
        }
        
    }
    
    /**
     * Metodo que valida la serie de un automovil
     * @param s Cadena a evaluar
     * @return EL resultado de la validacion
     */
    public boolean validaSerie(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z0-9]{8}))";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida la marca de un automovil
     * @param s Cadena a evaluar
     * @return EL resultado de la validacion
     */
    public boolean validaMarca(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)){4,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida la linea de un automovil
     * @param s Cadena a evaluar
     * @return EL resultado de la validacion
     */
    public boolean validaLinea(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)(\\s[a-zA-Z])*){3,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida el color de un automovil
     * @param s Cadena a evaluar
     * @return EL resultado de la validacion
     */
    public boolean validaColor(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)(\\s[a-zA-Z])*){4,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida el modelo de un automovil
     * @param s Cadena a evaluar
     * @return EL resultado de la validacion
     */
    public boolean validaModelo(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z0-9]+)){3,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    /**
     * Metodo que valida que una cadena cuente con el formato adecuado de una fecha
     * @param s Cadena a evaluar
     * @return EL resultado de la validacion
     */
    public boolean validaStringFecha(String s){
        CharSequence cadena=s.trim();
        String reCadena="([0-2][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9])";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
}
