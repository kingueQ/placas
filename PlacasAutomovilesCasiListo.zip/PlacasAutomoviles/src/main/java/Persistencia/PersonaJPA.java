/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import entidades.Persona;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 * Clase que guarda todos los metodos de las personas
 * @author Abraham Quintana y Juan Gamez
 */
public class PersonaJPA implements Serializable{
    
   private EntityManagerFactory em = null;

   /**
    * Contructor por omision
    */
    public PersonaJPA() {
        em = Persistence.createEntityManagerFactory("ConexionPU");
    }
    
    /**
     * Metodo que obtiene una instancia de entitymanager
     * @return Una instancia de entitymanager
     */
    public EntityManager getEntityManager() {
        return em.createEntityManager();
    }

    /**
     * Metodo que agrega una persona a la base de datos
     * @param persona Persona a agregar
     * @return La persona agregada
     */
    public Persona agregarPersona(Persona persona) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(persona);
            em.getTransaction().commit();
            return persona;
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
                
            }
        } finally {
            if (em != null) {
                em.close();
                return null;
            }
        }
       return null;
    }
    
    /**
     * Metodo que busca una persona
     * @param RFC RFC de la persona
     * @return La persona encontrada
     */
    public Persona buscarPersona(String RFC) {
        EntityManager em = null;
        Persona persona = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Persona p where p.RFC = :RFC");
            query.setParameter("RFC", RFC);
            persona = (Persona) query.getSingleResult();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return persona;
    }
    
    /**
     * Metodo que busca una persona mediante su fecha de nacimiento
     * @param fechaNac Fecha de nacimiento
     * @return La persona con esa fecha de nacimiento
     */
    public Persona buscarPersonaFecha(Date fechaNac){
        EntityManager em = null;
        Persona persona = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Persona p where p.fecha_nacimiento = :fechaNac");
            query.setParameter("fechaNac", fechaNac);
            persona = (Persona) query.getSingleResult();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return persona;
    }
    
    /**
     * Metodo que busca las persona por su nombre
     * @param nombre Nombre de la persona
     * @return La lista de personas
     */
    public List<Persona> buscarPersonasNombre(String nombre){
        EntityManager em = null;
        String nom="";
        nom=nom+"%";
        nom=nom+nombre;
        nom=nom+"%";
        List<Persona> personas=null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Persona p where CONCAT(p.nombres, p.apellidoP, p.apellidoM) like :nom");
            query.setParameter("nom", nom);
            personas = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return personas;
    }
}
