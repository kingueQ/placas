/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import entidades.Automovil;
import java.io.Serializable;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Clase que guarda los metodos de los automoviles
 * @author Abraham Quintana y Juan Gamez
 */
public class AutomovilJPA implements Serializable {

    private EntityManagerFactory emf = null;

    /**
     * Contructor por omision
     */
    public AutomovilJPA(){
        emf=Persistence.createEntityManagerFactory("ConexionPU");
    }
    
    /**
     * Metodo que obtiene una instancia de entitymanager
     * @return Una instancia de entitymanager
     */
    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    /**
     * Metodo que agrega un automovil
     * @param auto Automovil a agregar
     * @return El automovil agregado
     */
    public Automovil agregarAutomovil(Automovil auto) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(auto);
            em.getTransaction().commit();
            auto=this.buscarAutomovil(auto.getSerie());
            return auto;
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
                return null;
            }
        } finally {
            if (em != null) {
                em.close();
                return auto;
            }
        }
        return auto;
    }
    
    /**
     * Metodo que busca un automovil
     * @param serie Serie del automovil
     * @return El automovil encontrado
     */
    public Automovil buscarAutomovil(String serie) {
        EntityManager em = null;
        Automovil auto = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT a FROM Automovil a where a.serie = :serie");
            query.setParameter("serie", serie);
            auto = (Automovil) query.getSingleResult();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return auto;
    }
    
    /**
     * Metodo que busca los automoviles de una persona
     * @param rfc RFC de la persona
     * @return La lista de automoviles
     */
    public List<Automovil> buscarAutomoviles(String rfc) {
        EntityManager em = null;
        List<Automovil> autos = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT a FROM Automovil a where a.persona.RFC = :RFC");
            query.setParameter("RFC", rfc);
            autos = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return autos;
    }
    
    /**
     * Metodo que busca el automovil con cierta placa
     * @param numero Numero de la placa
     * @return El automovil con esa placa
     */
    public Automovil buscarAutomovilPlaca(String numero){
        EntityManager em = null;
        Automovil auto = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT a.automovil FROM Placa a where a.numero = :numero");
            query.setParameter("numero", numero);
            auto = (Automovil) query.getSingleResult();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return auto;
    }
}
