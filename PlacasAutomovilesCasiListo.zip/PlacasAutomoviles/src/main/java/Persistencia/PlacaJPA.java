/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import java.io.Serializable;
import javax.persistence.Query;
import entidades.Placa;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Clase que guarda los metodos de las placas
 * @author Abraham Quintana y Juan Gamez
 */
public class PlacaJPA implements Serializable {

    private EntityManagerFactory emf = null;

    /**
     * Constructor por omision
     */
    public PlacaJPA(){
        emf=Persistence.createEntityManagerFactory("ConexionPU");
    }
    
    /**
     * Metodo que crea una instancia de entitymanager
     * @return La instancia de un entitymanager
     */
    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    /**
     * Metodo que agrega una placa a la base de datos
     * @param placa Placa a agregar
     * @return La placa agregada
     */
    public Placa agregarPlaca(Placa placa) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(placa);
            em.getTransaction().commit();
            placa=this.buscarPlaca(placa.getNumero());
            return placa;
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
                return null;
            }
        } finally {
            if (em != null) {
                em.close();
                return placa;
            }
        }
       return placa;
    }
    
    /**
     * Metodo que busca una placa
     * @param numero Numero de la placa a buscar
     * @return La placa encontrada
     */
    public Placa buscarPlaca(String numero) {
        EntityManager em = null;
        Placa placa = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Placa p where p.numero = :numero");
            query.setParameter("numero", numero);
            placa = (Placa) query.getSingleResult();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return placa;
    }
    
    /**
     * Metodo que busca las placas de un automovil
     * @param serie Serie del auto
     * @return La lista de las placas pertenecientes a dicho auto
     */
    public List<Placa> buscarPlacas(String serie) {
        EntityManager em = null;
        List<Placa> placas = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Placa p where p.Automovil.Serie = :Serie");
            query.setParameter("Serie", serie);
            placas = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return placas;
    }
    
    /**
     * Metodo que cancela una placa
     * @param placa Placa a desactivar
     * @return Si la placa se cancelo o no
     */
    public boolean cancelarPlaca(Placa placa) {
        EntityManager em = null;
        boolean exito=true;
        placa.setActiva(false);
        placa.setFecha_recepcion(new Date());
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(placa);
            em.getTransaction().commit();
            exito=true;
            return exito;
            
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
                exito=false;
                return exito;
            }
        } finally {
            if (em != null) {
                em.close();
                return exito;
            }
        }
        return exito;
    }
    
    /**
     * Metodo que busca la placa activa de un auto
     * @param serie Serie del auto
     * @return La placa activa del auto dado
     */
    public Placa buscarPlacaActiva(String serie) {
        EntityManager em = null;
        Placa placa = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Placa p where p.automovil.serie = :serie AND p.activa=true");
            query.setParameter("serie", serie);
            placa = (Placa) query.getSingleResult();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return placa;
    }
    
    /**
     * Metodo que busca las placas pertenecientes a los autos de una persona
     * @param rfc RFC de la persona
     * @return Las placas de los autos de la persona
     */
    public List<Placa> buscarPlacasPersona(String rfc) {
        EntityManager em = null;
        List<Placa> placas = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Placa p where p.automovil.persona.RFC = :RFC");
            query.setParameter("RFC", rfc);
            placas = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return placas;
    }
    
    /**
     * Metodo que busca las placas activas de una persona
     * @param rfc RFC de la persona
     * @return Las placas de la persona
     */
    public List<Placa> buscarPlacasActivasPersona(String rfc) {
        EntityManager em = null;
        List<Placa> placas = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Placa p where p.automovil.persona.RFC = :RFC AND p.activa=true");
            query.setParameter("RFC", rfc);
            placas = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return placas;
    }
    
    /**
     * Metodo que busca las placas de una persona con cierta fecha de nacimiento
     * @param fecha Fecha de nacimiento
     * @return La lista de las placas
     */
    public List<Placa> buscarPlacasFecha(Date fecha){
        EntityManager em = null;
        List<Placa> placas = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Placa p where p.automovil.persona.fecha_nacimiento = :Fecha");
            query.setParameter("Fecha", fecha);
            placas = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return placas;
    }
    
    /**
     * Metodo que busca las placas mediante el nombre de una persona
     * @param nombre Nombre de la persona
     * @return La lista de placas
     */
    public List<Placa> buscarPlacasNombre(String nombre){
        EntityManager em = null;
        String nom="";
        nom=nom+"%";
        nom=nom+nombre;
        nom=nom+"%";
        List<Placa> placas = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT p FROM Placa p where CONCAT(p.automovil.persona.nombres, p.automovil.persona.apellidoP, p.automovil.persona.apellidoM) like :nom");
            query.setParameter("nom", nom);
            placas = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return placas;
    }
    
    /**
     * Metodo que obtiene las placas expedidas en cierto intervalo de tiempo
     * @param inicio Inicio del intervalo
     * @param fin Fin del intervalo
     * @return La lista de placas dentro de ese intervalo
     */
    public List<Placa> consultarIntervalo(Date inicio, Date fin){
        if(inicio==null && fin==null){
            return this.buscarTodas();
        }else if(inicio==null){
            EntityManager em = null;
            List<Placa> placas = new ArrayList<>();
            try {
                em = getEntityManager();
                em.getTransaction().begin();
                Query query = em.createQuery("SELECT p FROM Placa p WHERE p.fecha_emision < :fin");
                query.setParameter("fin", fin);
                placas = query.getResultList();
                em.getTransaction().commit();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
            em.close();
            return placas;
        }else if(fin==null){
            EntityManager em = null;
            List<Placa> placas = new ArrayList<>();
            try {
                em = getEntityManager();
                em.getTransaction().begin();
                Query query = em.createQuery("SELECT p FROM Placa p WHERE p.fecha_emision > :inicio");
                query.setParameter("inicio", inicio);
                placas = query.getResultList();
                em.getTransaction().commit();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
            em.close();
            return placas;
        }else{
            EntityManager em = null;
            List<Placa> placas = new ArrayList<>();
            try {
                em = getEntityManager();
                em.getTransaction().begin();
                Query query = em.createQuery("SELECT p FROM Placa p WHERE p.fecha_emision < :fin AND p.fecha_emision > :inicio");
                query.setParameter("fin", fin);
                query.setParameter("inicio", inicio);
                placas = query.getResultList();
                em.getTransaction().commit();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
            em.close();
            return placas;
        }
    }
    
    /**
     * Metodo que obtiene todas las placas
     * @return La lista de todas las placas
     */
    public List<Placa> buscarTodas(){
        EntityManager em = null;
            List<Placa> placas = new ArrayList<>();
            try {
                em = getEntityManager();
                em.getTransaction().begin();
                Query query = em.createQuery("SELECT p FROM Placa p");
                placas = query.getResultList();
                em.getTransaction().commit();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
            em.close();
            return placas;
    }
}
