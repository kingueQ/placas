/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import entidades.Licencia;
import entidades.Persona;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 * Clase que guarda los metodos de las licencias
 * @author Abraham Quintana y Juan Gamez
 */
public class LicenciaJPA implements Serializable {

    private EntityManagerFactory em = null;

    /**
     * Constructor por omision
     */
    public LicenciaJPA() {
        em = Persistence.createEntityManagerFactory("ConexionPU");
    }

    /**
     * Metodo que obtiene una instancia de entitymanager
     * @return Una instancia de entitymanager
     */
    public EntityManager getEntityManager() {
        return em.createEntityManager();
    }

    /**
     * Metodo que agrega una licencia a la base de datos
     * @param licencia Licencia a agregar
     * @return Licencia que se agrego
     */
    public Licencia agregarLicencia(Licencia licencia) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(licencia);
            em.getTransaction().commit();
            return licencia;
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());

            }
        } finally {
            if (em != null) {
                em.close();
                return null;
            }
        }
        return null;
    }

    /**
     * Metodo que obtiene los años de la licencia
     * @param persona Persona a la que pertenece la licencia
     * @return Los años de la licencia
     */
    public Long añosLicencia(Persona persona) {
        int id = persona.getId();
        EntityManager em = null;
        em = getEntityManager();
        em.getTransaction().begin();
        CriteriaBuilder cb = em.getCriteriaBuilder();

        CriteriaQuery<Long> cq = cb.createQuery(Long.class);
        Root<Licencia> root = cq.from(Licencia.class);

        cq.select(cb.function("TIMESTAMPDIFF", Long.class,
                cb.literal("YEAR"),
                root.get("fecha_expedicion"),
                cb.currentTimestamp()))
                .where(cb.and(
                        cb.equal(root.get("persona").get("id"), id),
                        cb.equal(root.get("activa"), false)
                ));

        TypedQuery<Long> query = em.createQuery(cq);
        Long años = query.getSingleResult();
        em.getTransaction().commit();
        return años;
    }

    /**
     * Metodo que obtiene la licencia activa de una persona
     * @param persona Persona a la que pertenece la licencia
     * @return La licencia activa
     */
    public Licencia LicenciaActiva(Persona persona) {
        int id = persona.getId();
        EntityManager em = null;
        em = getEntityManager();
        em.getTransaction().begin();
        Query query = em.createQuery("SELECT l FROM Licencia l WHERE l.persona.id = :idPersona AND l.activa = false");
        query.setParameter("idPersona", id);
        List<Licencia> licencias = query.getResultList();
        if (licencias.isEmpty()) {
             return null;
        } else {
           Licencia licencia = licencias.get(0);
           return licencia;
        }      
    }
    
    /**
     * Metodo que desactiva una licencia
     * @param licencia Licencia a desactivar
     */
    public void desactivarLicencia(Licencia licencia){
      EntityManager em = null;
      licencia.setActiva(true);
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(licencia);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (em != null) {
                em.getTransaction().rollback();
                System.err.print(ex.getMessage());
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }        
    }
    
    /**
     * Metodo que obtiene las licencias de una persona
     * @param RFC RFC de la persona
     * @return La lista de licencias
     */
    public List<Licencia> buscarLicenciasPersona(String RFC){
        EntityManager em = null;
        List<Licencia> licencias = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT l FROM Licencia l where l.persona.RFC = :RFC");
            query.setParameter("RFC", RFC);
            licencias = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return licencias;
    }

    /**
     * Metodo que busca las licencias que pertenecen a cierta persona
     * @param nombre nombre de la persona
     * @return La lista de licencias
     */
    public List<Licencia> buscarLicenciasNombre(String nombre){
        EntityManager em = null;
        String nom="";
        nom=nom+"%";
        nom=nom+nombre;
        nom=nom+"%";
        List<Licencia> licencias = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT l FROM Licencia l where CONCAT(l.persona.nombres, l.persona.apellidoP, l.persona.apellidoM) like :nom");
            query.setParameter("nom", nom);
            licencias = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return licencias;
    }
    
    /**
     * Metodo que obtiene las licencias de las persona con cierta fecha de nacimiento
     * @param fecha Fecha de nacimiento
     * @return La lista de licencias
     */
    public List<Licencia> buscarLicenciasFecha(Date fecha){
        EntityManager em = null;
        List<Licencia> licencias = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT l FROM Licencia l where l.persona.fecha_nacimiento = :Fecha");
            query.setParameter("Fecha", fecha);
            licencias = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return licencias;
    }
    
    /**
     * Metodo que obtiene las licencias expedidas en un intervalo de tiempo
     * @param inicio Inicio del intevalo
     * @param fin Fin del intervalo
     * @return Lista de licencias
     */
    public List<Licencia> consultarIntervalo(Date inicio, Date fin){
        if(inicio==null && fin==null){
            return this.buscarTodas();
        }else if(inicio==null){
            EntityManager em = null;
            List<Licencia> licencias = new ArrayList<>();
            try {
                em = getEntityManager();
                em.getTransaction().begin();
                Query query = em.createQuery("SELECT l FROM Licencia l WHERE l.fecha_expedicion < :fin");
                query.setParameter("fin", fin);
                licencias = query.getResultList();
                em.getTransaction().commit();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
            em.close();
            return licencias;
        }else if(fin==null){
            EntityManager em = null;
            List<Licencia> licencias = new ArrayList<>();
            try {
                em = getEntityManager();
                em.getTransaction().begin();
                Query query = em.createQuery("SELECT l FROM Licencia l WHERE l.fecha_expedicion > :inicio");
                query.setParameter("inicio", inicio);
                licencias = query.getResultList();
                em.getTransaction().commit();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
            em.close();
            return licencias;
        }else{
            EntityManager em = null;
            List<Licencia> licencias = new ArrayList<>();
            try {
                em = getEntityManager();
                em.getTransaction().begin();
                Query query = em.createQuery("SELECT l FROM Licencia l WHERE l.fecha_expedicion < :fin AND l.fecha_expedicion > :inicio");
                query.setParameter("fin", fin);
                query.setParameter("inicio", inicio);
                licencias = query.getResultList();
                em.getTransaction().commit();
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
            em.close();
            return licencias;
        }
    }
    
    /**
     * Metodo que obtiene todas las licencias registradas
     * @return La lista de licencias
     */
    public List<Licencia> buscarTodas(){
        EntityManager em = null;
        List<Licencia> licencias = new ArrayList<>();
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Query query = em.createQuery("SELECT l FROM Licencia l");
            licencias = query.getResultList();
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        em.close();
        return licencias;
    }
}
