/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 * Clase Automovil
 * @author Abraham Quintana y Juan Gamez
 */
@Entity
public class Automovil implements Serializable {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Basic
    private String serie;
    private String modelo;
    private String color;
    private String linea;
    private String marca;
    
    
    @ManyToOne()
    @JoinColumn(name = "persona_id")
    private Persona persona;
    
    @OneToMany(mappedBy = "automovil", cascade = CascadeType.PERSIST)
    private List<Placa> placas;

    public Automovil() {
    }

    public Automovil(String serie, String modelo, String color, String linea, String marca, Persona persona) {
        this.serie = serie;
        this.modelo = modelo;
        this.color = color;
        this.linea = linea;
        this.marca = marca;
        this.persona = persona;
    }

    public Automovil(Integer id, String serie, String modelo, String color, String linea, String marca, Persona persona) {
        this.id = id;
        this.serie = serie;
        this.modelo = modelo;
        this.color = color;
        this.linea = linea;
        this.marca = marca;
        this.persona = persona;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getLinea() {
        return linea;
    }

    public void setLinea(String linea) {
        this.linea = linea;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public List<Placa> getPlacas() {
        return placas;
    }

    public void setPlacas(List<Placa> placas) {
        this.placas = placas;
    }

    @Override
    public String toString() {
        return "Automovil{" + "id=" + id + ", serie=" + serie + ", modelo=" + modelo + ", color=" + color + ", linea=" + linea + ", marca=" + marca + ", persona=" + persona + ", placas=" + placas + '}';
    }
    
    
}
