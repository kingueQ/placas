/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package principal;

import Entidades.Direccion;
import Entidades.Jugador;
import Entidades.Logro;
import Entidades.VideoJuego;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Maria
 */
public class Pruebas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // CREAMOS UNA FACTORY DE ENTITY MANAGERS
        EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("ConexionPU");
        // CREAMOS UN OBJETO EM QUE REPRESENTA A LA BD EN CÓDIGO
        EntityManager entityManager = managerFactory.createEntityManager();
        //creamos una direccion
        Direccion d = new Direccion(1, "ITSON", 123, "Villa Itson");
        //creamos listas vacias que despues les daremos valores
        List<Jugador> jugadores = new ArrayList<>();
        List<VideoJuego> videojuegos = new ArrayList<>();
        List<Logro> logros = new ArrayList<>();
        VideoJuego v=null;
        
        
        //creamos un logro
        Logro logro = new Logro(1, "winwin", 100, v);
        
        
        //creamos un jugador
        Jugador j = new Jugador(1, "abcd", "mujer", new Date(98,5,22),d,videojuegos);
        
        //creamos un videojuego
        v = new VideoJuego(1, "mario jgvutgbh", 100, "abc", jugadores,logros );
        logro.setVideojuego(v);
        logros.add(logro);
        v.setLogros(logros);
        
        //añadimos a las listas correspondientes
        jugadores.add(j);
        videojuegos.add(v);
        
        //se los mandamos a cada entidad
        j.setVideojuegos(videojuegos);
        v.setJugadores(jugadores);

        //INICIAMOS LA TRANSACCION
        entityManager.getTransaction().begin();
        
        //enviamos el jugador y la direccion
        entityManager.persist(j);
        entityManager.persist(v);
        
        //MANDAMOS A EJECUTAR LA TRANSACCION
        entityManager.getTransaction().commit();
        //CERRAMOS
        entityManager.close();
        //managerFactory.close();

    }

}
