/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Maria
 */
@Entity
public class Jugador implements Serializable {

   
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_jugador", nullable = false)
    private Integer idJugador;
    
    private String pseudonimo;
    private String sexo;
    
    @Temporal (TemporalType.DATE)
    private Date fechaNacimiento;
    
    @OneToOne (cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
    @JoinColumn(name = "id_direccion", nullable = false)
    private Direccion direccion;
    
    @ManyToMany(mappedBy = "jugadores")
    private List<VideoJuego> videojuegos;

    public Jugador() {
    }

    public Jugador(Integer idJugador, String pseudonimo, String sexo, Date fechaNacimiento, Direccion direccion, List<VideoJuego> videojuegos) {
        this.idJugador = idJugador;
        this.pseudonimo = pseudonimo;
        this.sexo = sexo;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
        this.videojuegos = videojuegos;
    }

    public List<VideoJuego> getVideojuegos() {
        return videojuegos;
    }

    public void setVideojuegos(List<VideoJuego> videojuegos) {
        this.videojuegos = videojuegos;
    }

   

    public Integer getIdJugador() {
        return idJugador;
    }

    public void setIdJugador(Integer idJugador) {
        this.idJugador = idJugador;
    }

    public String getPseudonimo() {
        return pseudonimo;
    }

    public void setPseudonimo(String pseudonimo) {
        this.pseudonimo = pseudonimo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Jugador{" + "idJugador=" + idJugador + ", pseudonimo=" + pseudonimo + ", sexo=" + sexo + ", fechaNacimiento=" + fechaNacimiento + ", direccion=" + direccion + '}';
    }

    
    
    

   
}
