/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

/**
 *
 * @author Maria
 */
@Entity
public class VideoJuego implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Basic
    private String nombre;
    private int puntaje;
    private String desarrolladora;
    
    @ManyToMany (cascade = {CascadeType.PERSIST,CascadeType.MERGE})
    @JoinTable(
            name= "jugador_videojuego",
            joinColumns = @JoinColumn (name = "id_videojuego"),
            inverseJoinColumns = @JoinColumn(name = "id_jugadores")
    )
    List<Jugador> jugadores;
    
    @OneToMany (mappedBy = "videojuego", cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
    List<Logro> logros;

    public VideoJuego() {
    }

    public VideoJuego(Integer id, String nombre, int puntaje, String desarrolladora, List<Jugador> jugadores, List<Logro> logros) {
        this.id = id;
        this.nombre = nombre;
        this.puntaje = puntaje;
        this.desarrolladora = desarrolladora;
        this.jugadores = jugadores;
        this.logros = logros;
    }

    public List<Logro> getLogros() {
        return logros;
    }

    public void setLogros(List<Logro> logros) {
        this.logros = logros;
    }

    

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(int puntaje) {
        this.puntaje = puntaje;
    }

    public String getDesarrolladora() {
        return desarrolladora;
    }

    public void setDesarrolladora(String desarrolladora) {
        this.desarrolladora = desarrolladora;
    }

    public List<Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(List<Jugador> jugadores) {
        this.jugadores = jugadores;
    }

    @Override
    public String toString() {
        return "VideoJuego{" + "id=" + id + ", nombre=" + nombre + ", puntaje=" + puntaje + ", desarrolladora=" + desarrolladora + ", jugadores=" + jugadores + '}';
    }
    
    
    

}
