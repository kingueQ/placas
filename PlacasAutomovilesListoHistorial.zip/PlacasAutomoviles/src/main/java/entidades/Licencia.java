/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author kingu
 */
@Entity
@DiscriminatorValue("licencia")
@Table(name = "licencia")
public class Licencia extends Tramite implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Basic
    @Column(name = "vigencia")
    private int vigencia;

    @Basic
    @Column(name = "costo")
    private double costo;

    @Basic
    @Column(name = "activa", columnDefinition = "BOOLEAN DEFAULT true")
    private boolean activa;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "fecha_expedicion", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Date fecha_expedicion;

    @ManyToOne
    @JoinColumn(name = "id_persona")
    private Persona persona;

    public Licencia() {
    }

    public Licencia(int vigencia, double costo, Date fecha_expedicion, Persona persona) {
        this.vigencia = vigencia;
        this.costo = costo;
        this.fecha_expedicion = fecha_expedicion;
        this.persona = persona;
    }

    public Licencia(Integer id, int vigencia, double costo, boolean activa, Date fecha_expedicion, Persona persona) {
        this.id = id;
        this.vigencia = vigencia;
        this.costo = costo;
        this.activa = activa;
        this.fecha_expedicion = fecha_expedicion;
        this.persona = persona;
    }

    public Licencia(int vigencia, double costo, boolean activa, Date fecha_expedicion, Persona persona) {
        this.vigencia = vigencia;
        this.costo = costo;
        this.activa = activa;
        this.fecha_expedicion = fecha_expedicion;
        this.persona = persona;
    }

    public Licencia(int vigencia, double costo, Persona persona) {
        this.vigencia = vigencia;
        this.costo = costo;
        this.persona = persona;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getVigencia() {
        return vigencia;
    }

    public void setVigencia(int vigencia) {
        this.vigencia = vigencia;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public Date getFecha_expedicion() {
        return fecha_expedicion;
    }

    public void setFecha_expedicion(Date fecha_expedicion) {
        this.fecha_expedicion = fecha_expedicion;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    @Override
    public String toString() {
        return "Licencia{" + "id=" + id + ", vigencia=" + vigencia + ", costo=" + costo + ", fecha_expedicion=" + fecha_expedicion + ", persona=" + persona + '}';
    }

}
