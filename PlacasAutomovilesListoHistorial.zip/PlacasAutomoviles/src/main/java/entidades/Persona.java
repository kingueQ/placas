/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author kingu
 */
@Entity
@Table(name = "Persona")
public class Persona implements Serializable {

    @Id
    @Column(name = "id_persona")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Basic
    @Column(name = "rfc")
    private String RFC;
    @Basic
    @Column(name = "telefono")
    private String telefono;
    @Basic
    @Column(name = "apellido_Paterno")
    private String apellidoP;
    @Basic
    @Column(name = "apellido_Materno")
    private String apellidoM;
    @Basic
    @Column(name = "nombres")
    private String nombres;
    
    @Basic
    @Column(name = "esDiscapacitado")
    private boolean esDiscapacitado;

    @Temporal(TemporalType.DATE)
    @Column(name = "fecha_nacimiento")
    private Date fecha_nacimiento;

    @OneToMany(mappedBy = "persona", cascade = CascadeType.PERSIST)
    private List<Automovil> autos;

   

    @OneToMany(mappedBy = "persona")
    private List<Licencia> licencias;

    public Persona() {
    }

    public Persona(String RFC, String telefono, String apellidoP, String apellidoM, String nombres, boolean esDiscapacitado, Date fecha_nacimiento) {
        this.RFC = RFC;
        this.telefono = telefono;
        this.apellidoP = apellidoP;
        this.apellidoM = apellidoM;
        this.nombres = nombres;
        this.esDiscapacitado = esDiscapacitado;
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public Persona(Integer id, String RFC, String telefono, String apellidoP, String apellidoM, String nombres, boolean esDiscapacitado, Date fecha_nacimiento, List<Automovil> autos) {
        this.id = id;
        this.RFC = RFC;
        this.telefono = telefono;
        this.apellidoP = apellidoP;
        this.apellidoM = apellidoM;
        this.nombres = nombres;
        this.esDiscapacitado = esDiscapacitado;
        this.fecha_nacimiento = fecha_nacimiento;
        this.autos = autos;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRFC() {
        return RFC;
    }

    public void setRFC(String RFC) {
        this.RFC = RFC;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getApellidoP() {
        return apellidoP;
    }

    public void setApellidoP(String apellidoP) {
        this.apellidoP = apellidoP;
    }

    public String getApellidoM() {
        return apellidoM;
    }

    public void setApellidoM(String apellidoM) {
        this.apellidoM = apellidoM;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public boolean isEsDiscapacitado() {
        return esDiscapacitado;
    }

    public void setEsDiscapacitado(boolean esDiscapacitado) {
        this.esDiscapacitado = esDiscapacitado;
    }

    public Date getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(Date fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public List<Automovil> getAutos() {
        return autos;
    }

    public void setAutos(List<Automovil> autos) {
        this.autos = autos;
    }



    public List<Licencia> getLicencias() {
        return licencias;
    }

    public void setLicencias(List<Licencia> licencias) {
        this.licencias = licencias;
    }

   

}
