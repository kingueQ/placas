/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author kingu
 */
public class Validaciones {
    public boolean validaApellidoP(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)){3,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaApellidoM(String s){
        CharSequence cadena=s.trim();
        if(cadena.equals("")){
            return true;
        }
        String reCadena="^(([a-zA-Z]+)){3,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaNombres(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)(\\s[a-zA-Z])*){5,50}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaTelefono1(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([0-9]+)){10,12}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaTelefono2(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([0-9]+)&&-&&([0-9]+)&&-&&([0-9]+)){10,15}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaRFCSinHomoclave(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([A-Z]){4}([0-9]){6})";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaRFCConHomoclave(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([A-Z]){4}([0-9]){6}([A-Z0-9]){3})";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaTelefono(String s){
        if(validaTelefono1(s)){
           return true; 
        }else{
            return validaTelefono2(s);
        }
    }
    
    public boolean validaRFC(String s){
        if(validaRFCSinHomoclave(s)){
            return true;
        }else{
            return validaRFCConHomoclave(s);
        }
    }
    
    public boolean validaNacimiento(Date f){
        Date d=new Date();
        if(d.getYear()-f.getYear()>18){
            return true;
        }
        if(d.getYear()-f.getYear()<18){
            return false;
        }else{
            if(d.getMonth()>f.getMonth()){
                return true;
            }
            if(d.getMonth()<f.getMonth()){
                return false;
            }else{
                if(d.getDay()>=f.getDay()){
                    return true;
                }else{
                    return false;
                }
            }
        }
        
    }
    
    public boolean validaSerie(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z0-9]{8}))";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaMarca(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)){5,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaLinea(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)(\\s[a-zA-Z])*){5,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaColor(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z]+)(\\s[a-zA-Z])*){4,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaModelo(String s){
        CharSequence cadena=s.trim();
        String reCadena="^(([a-zA-Z0-9]+)){3,20}";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
    
    public boolean validaStringFecha(String s){
        CharSequence cadena=s.trim();
        String reCadena="([0-2][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9])";
        Pattern pattern = Pattern.compile(reCadena);
        Matcher matcher=pattern.matcher(cadena);
        return matcher.matches();
    }
}
